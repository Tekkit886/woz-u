namespace Lesson4HandsOn {
    public class Employees {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public string ReportsTo { get; set; }
        public int? BirthDate { get; set; }
        public int? HireDate { get; set; }
        public int? Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int PostalCode { get; set; }
        public int Phone { get; set; }
        public int Fax { get; set; }
        public string Email { get; set; }

    }
}