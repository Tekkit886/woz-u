﻿using System;

namespace Lesson5HandsOn
{
    class Program
    {
        static void Main(string[] args)
        {
            public class Person
            {
                string firstName;
                string lastName;
                string age;
            }
        }
    }
}
