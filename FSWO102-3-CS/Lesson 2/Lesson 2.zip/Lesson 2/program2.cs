using System;

namespace Lesson2
{
    static void Main(dtring[] args)
    {
        int age;
        bool isStudent = true;

        if (age <= 12) {
            Console.WriteLine("Child $8");
        }
        if (isStudent = true) {
            Console.WriteLine("Students $8");
        }
        if (age > 65) {
            Console.WriteLine("Senior Citizen $7");
        } else {
            Console.WriteLine("Everyone Else $10");
        }
    }
}