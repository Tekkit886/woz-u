using System;

namespace Lesson2
{
    static void Main(dtring[] args)
    {
        int age;
        if (age <= 12) {
            Console.WriteLine("Child $8");
        }
        if (age > 65) {
            Console.WriteLine("Senior Citizen $7");
        } else {
            Console.WriteLine("Everyone Else $10");
        }
    }
}