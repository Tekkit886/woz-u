﻿using System;
using AnotherProgram;

namespace HandsOnLesson6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I am text from the textNamespace.");
        }
    }
}
