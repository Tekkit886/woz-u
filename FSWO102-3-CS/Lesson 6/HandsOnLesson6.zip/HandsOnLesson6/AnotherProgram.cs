using System;
namespace myNamespace
{
    class AnotherProgram
    {
        public static void Main()
        {
            Console.WriteLine("Hello Earth!");
        }
    }
}

namespace specialSpace
{
    class specialSpace
    {
        public static void Main()
        {
            Console.WriteLine("Hello World!");
        }
    }
}