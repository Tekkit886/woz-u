﻿using System;
using Lesson6HandsOnSecond;

namespace Lesson6HandsOn
{
    class Program
        {
            public static void Main()
            {
                Console.WriteLine("This is the First Class!");
            }
        }

    class ClassTesting
        {
            public static void Main()
            {
                Console.WriteLine("This is the Second Class!");
            }
        }
}
