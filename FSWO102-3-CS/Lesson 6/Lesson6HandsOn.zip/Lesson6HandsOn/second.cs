using System;
using Lesson6HandsOn;

namespace Lesson6HandsOnSecond
{
    class ClassThree
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Class Three!");
        }
    }

    class ClassFour
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Class Four!");
        }
    }
}